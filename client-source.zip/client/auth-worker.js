import * as pgp from 'openpgp';
import {createIdentity,unlockIdentity,signChallenge,CRYPTO_CONFIG} from './crypto.js';

// Dedicated, short-lived local worker. Nothing here reads storage or sends
// network requests. The decrypted key crosses only the same-device worker port.
self.onmessage=async({data})=>{
 const {id,operation,args}=data||{};
 if(typeof id!=='string'||!Array.isArray(args))return;
 try{
  let result;
  if(operation==='create'){
   const identity=await createIdentity(args[0]);
   result={publicKey:identity.publicKey,encryptedPrivateKey:identity.encryptedPrivateKey,privateKeyArmored:identity.privateKey.armor(),fingerprint:identity.fingerprint};
  }else if(operation==='unlock'){
   const key=await unlockIdentity(args[0],args[1]);
   result={privateKeyArmored:key.armor()};
  }else if(operation==='sign'){
   if(typeof args[0]!=='string'||args[0].length>32768)throw new Error('Invalid local key');
   const key=await pgp.readPrivateKey({armoredKey:args[0],config:CRYPTO_CONFIG});
   if(key.keyPacket.version!==6||!key.isDecrypted())throw new Error('Invalid local key');
   result=await signChallenge(key,args[1],args[2]);
  }else throw new Error('Unknown operation');
  self.postMessage({id,ok:true,result});
 }catch(error){
  const detail=String(error?.message||'');
  const code=/memory|allocation|out of bounds/i.test(detail)?'MEMORY':/incorrect.*passphrase|decrypting private key/i.test(detail)?'PASSPHRASE':/挑战|challenge|时间/i.test(detail)?'CHALLENGE':/WebAssembly|not supported|not available/i.test(detail)?'UNSUPPORTED':'CRYPTO';
  self.postMessage({id,ok:false,code});
 }
};
