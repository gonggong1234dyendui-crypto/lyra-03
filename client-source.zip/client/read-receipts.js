// Read receipts contain signed message UUIDs, never relay-assigned row IDs as proof.
// The caller passes only messages/receipts whose encryption, signature and binding
// have already been checked by the normal message path.
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ACCOUNT=/^[1-9]\d{19}$/;
const MAX_BATCH=64;

export function createReceiptLedger(){
  const selfRead=new Map(),peerRead=new Map();
  return {
    accept(payload,selfId){
      if(payload?.type!=='receipt'||payload.readVersion!==1||!ACCOUNT.test(selfId)||!ACCOUNT.test(payload.from)||!ACCOUNT.test(payload.to)||payload.from===payload.to)return null;
      const own=payload.from===selfId;
      if(!own&&payload.to!==selfId)return null;
      const ids=payload.readClientIds;
      if(!Array.isArray(ids)||ids.length<1||ids.length>MAX_BATCH||ids.some(id=>typeof id!=='string'||!UUID.test(id)))return null;
      const peerId=own?payload.to:payload.from,store=own?selfRead:peerRead;
      let set=store.get(peerId);if(!set){set=new Set();store.set(peerId,set)}
      let changed=false;for(const id of ids){if(!set.has(id)){set.add(id);changed=true}}
      return {peerId,by:own?'self':'peer',changed};
    },
    hasSelfRead(peerId,clientId){return selfRead.get(peerId)?.has(clientId)||false},
    hasPeerRead(peerId,clientId){return peerRead.get(peerId)?.has(clientId)||false},
    clear(){selfRead.clear();peerRead.clear()}
  };
}

export function readReceiptBody(rows){
  if(!Array.isArray(rows)||!rows.length||rows.length>MAX_BATCH)throw Error('Invalid read-receipt batch');
  const ids=[];let messageId=0;
  for(const row of rows){if(!UUID.test(row.clientId)||!Number.isSafeInteger(row.id)||row.id<=0)throw Error('Invalid read-receipt target');if(!ids.includes(row.clientId))ids.push(row.clientId);messageId=Math.max(messageId,row.id)}
  // messageId keeps compatibility with the initial encrypted-payload validator.
  // Only readClientIds is authoritative; changing an opaque relay ID cannot mark
  // another message as read.
  return {type:'receipt',messageId,readVersion:1,readClientIds:ids};
}

function intersection(a,b){return {left:Math.max(a.left,b.left),top:Math.max(a.top,b.top),right:Math.min(a.right,b.right),bottom:Math.min(a.bottom,b.bottom)}}
export function isVisuallyReadable(element,root,doc,win){
  if(!element?.isConnected||!root?.isConnected||doc.visibilityState!=='visible'||doc.hidden||!doc.hasFocus()||doc.querySelector('dialog[open]'))return false;
  const rect=element.getBoundingClientRect(),rootRect=root.getBoundingClientRect();
  if(rect.width<=0||rect.height<=0||rootRect.width<=0||rootRect.height<=0)return false;
  for(const node of [element,root]){const style=win.getComputedStyle(node);if(style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse'||Number(style.opacity)===0)return false}
  const viewport=win.visualViewport,view={left:viewport?.offsetLeft||0,top:viewport?.offsetTop||0,right:(viewport?.offsetLeft||0)+(viewport?.width||win.innerWidth),bottom:(viewport?.offsetTop||0)+(viewport?.height||win.innerHeight)};
  const clip=intersection(rootRect,view),visible=intersection(rect,clip);
  const availableHeight=clip.bottom-clip.top,availableWidth=clip.right-clip.left;
  if(availableHeight<=0||availableWidth<=0)return false;
  const visibleHeight=Math.max(0,visible.bottom-visible.top),visibleWidth=Math.max(0,visible.right-visible.left);
  if(visibleHeight<Math.min(rect.height,availableHeight)*.7||visibleWidth<Math.min(rect.width,availableWidth)*.7)return false;
  const top=doc.elementFromPoint?.((visible.left+visible.right)/2,(visible.top+visible.bottom)/2);
  return !doc.elementFromPoint||!!top&&(top===element||element.contains(top));
}

export function createVisualReadTracker({getCurrentPeerId,hasRead=()=>false,onRead,document:doc=globalThis.document,window:win=globalThis.window,dwellMs=1200,now=()=>performance.now(),setTimer=(fn,ms)=>win.setTimeout(fn,ms),clearTimer=id=>win.clearTimeout(id)}={}){
  if(typeof onRead!=='function'||typeof getCurrentPeerId!=='function'||!doc||!win)throw Error('Read tracker needs a visible document and handlers');
  let peerId=null,root=null,rows=[],timer=null,observer=null,mutation=null,listening=false,revision=0;
  const since=new Map(),pending=new Set(),confirmed=new Set(),retryAfter=new Map(),candidates=new Set(),listeners=[];
  function clearScheduled(){if(timer!==null){clearTimer(timer);timer=null}}
  function listen(target,type,fn,options){target?.addEventListener?.(type,fn,options);listeners.push(()=>target?.removeEventListener?.(type,fn,options))}
  function resetDwell(){since.clear();clearScheduled()}
  function wake(){clearScheduled();refresh()}
  function blur(){resetDwell()}
  function install(){
    if(listening)return;listening=true;
    listen(win,'blur',blur);listen(win,'focus',wake);listen(doc,'visibilitychange',()=>doc.hidden?blur():wake());
    listen(win,'resize',wake);listen(win.visualViewport,'resize',wake);listen(win.visualViewport,'scroll',wake);
    listen(doc,'scroll',wake,true);listen(doc,'close',wake,true);
    if(win.MutationObserver){mutation=new win.MutationObserver(wake);mutation.observe(doc.body,{subtree:true,childList:true,attributes:true,attributeFilter:['open','hidden','class','style']})}
  }
  function schedule(){if(timer===null&&root)timer=setTimer(()=>{timer=null;refresh()},150)}
  async function send(batch,selectedPeer,selectedRevision){
    for(const row of batch)pending.add(selectedPeer+':'+row.clientId);
    try{await onRead({peerId:selectedPeer,body:readReceiptBody(batch),rows:batch});if(revision===selectedRevision)for(const row of batch)confirmed.add(row.clientId)}
    catch{if(revision===selectedRevision)for(const row of batch)retryAfter.set(row.clientId,now()+3000)}
    finally{for(const row of batch)pending.delete(selectedPeer+':'+row.clientId);if(revision===selectedRevision)refresh()}
  }
  function refresh(){
    if(!root||!root.isConnected||getCurrentPeerId()!==peerId||doc.visibilityState!=='visible'||doc.hidden||!doc.hasFocus()||doc.querySelector('dialog[open]')){resetDwell();return}
    const tick=now(),ready=[];let watching=false;
    for(const row of rows){
      if(hasRead(peerId,row.clientId)||confirmed.has(row.clientId)||pending.has(peerId+':'+row.clientId)){since.delete(row.clientId);continue}
      if((observer&&!candidates.has(row.element))||!isVisuallyReadable(row.element,root,doc,win)){since.delete(row.clientId);continue}
      watching=true;if(!since.has(row.clientId))since.set(row.clientId,tick);
      if(tick-since.get(row.clientId)>=dwellMs&&tick>=(retryAfter.get(row.clientId)||0)&&ready.length<MAX_BATCH)ready.push(row);
    }
    if(ready.length)void send(ready,peerId,revision);
    if(watching)schedule();
  }
  function stop(){
    revision++;resetDwell();observer?.disconnect();observer=null;mutation?.disconnect();mutation=null;
    for(const remove of listeners.splice(0))remove();listening=false;root=null;peerId=null;rows=[];candidates.clear();retryAfter.clear();confirmed.clear();
  }
  return {
    watch(selectedPeer,scrollRoot,targets){
      stop();if(!ACCOUNT.test(selectedPeer)||!scrollRoot)return;
      peerId=selectedPeer;root=scrollRoot;rows=targets.filter(row=>row.element&&UUID.test(row.clientId)&&Number.isSafeInteger(row.id)&&row.id>0);
      install();
      if(win.IntersectionObserver){observer=new win.IntersectionObserver(entries=>{for(const entry of entries){if(entry.isIntersecting)candidates.add(entry.target);else{candidates.delete(entry.target);const row=rows.find(r=>r.element===entry.target);if(row)since.delete(row.clientId)}}wake()},{root,threshold:[0,.7,1]});for(const row of rows)observer.observe(row.element)}
      refresh();
    },
    refresh,
    stop,
    destroy:stop
  };
}
