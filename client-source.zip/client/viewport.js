// The software keyboard can resize AND pan iOS's visual viewport independently
// of the document. Authentication uses native document scrolling; the chat UI
// and dialogs use the visible rectangle, without rebuilding their contents.
export function viewportMetrics({ height, width, visualHeight, visualWidth, top = 0, left = 0, scale = 1, editing = false }) {
  const positive = (value, fallback) => Number.isFinite(value) && value > 0 ? value : fallback;
  if (!Number.isFinite(scale) || Math.abs(scale - 1) > .01) return null;
  const viewHeight = Math.round(positive(visualHeight, positive(height, 1)));
  const viewWidth = Math.round(positive(visualWidth, positive(width, 1)));
  const viewTop = Math.max(0, Math.round(Number.isFinite(top) ? top : 0));
  const viewLeft = Math.max(0, Math.round(Number.isFinite(left) ? left : 0));
  return {
    height: viewHeight, width: viewWidth, top: viewTop, left: viewLeft,
    inset: editing ? Math.max(0, Math.round(positive(height, viewHeight) - viewTop - viewHeight)) : 0,
    compact: viewHeight <= 520 && viewWidth <= 900,
  };
}

export function installViewport(win = window, doc = document) {
  const html = doc.documentElement, root = doc.getElementById('root'), visual = win.visualViewport;
  let frame = 0, disposed = false;
  const properties = ['height', 'width', 'top', 'left'];
  const set = (name, value) => {
    if (html.style.getPropertyValue(name) !== value) html.style.setProperty(name, value);
  };
  function update() {
    frame = 0;
    if (disposed) return;
    const screen = root?.firstElementChild?.classList.contains('auth') ? 'auth' : root?.firstElementChild?.classList.contains('shell') ? 'shell' : 'loading';
    const messages = doc.getElementById('messages');
    // Preserve the latest message only if the reader was already at the end.
    // Reading older history must never jump to the bottom on a keyboard resize.
    const pinned = messages && messages.clientHeight > 0 && Math.abs(messages.scrollHeight - messages.clientHeight - messages.scrollTop) <= 2;
    const editing = !!doc.activeElement?.matches('input:not([type="checkbox"]):not([type="radio"]), textarea, [contenteditable="true"]');
    const metrics = viewportMetrics({ height: win.innerHeight, width: win.innerWidth, visualHeight: visual?.height, visualWidth: visual?.width, top: visual?.offsetTop, left: visual?.offsetLeft, scale: visual?.scale ?? 1, editing });
    html.dataset.screen = screen;
    // Leave pinch zoom to the browser; do not stretch or chase the zoomed view.
    if (!metrics) return;
    for (const name of properties) set('--view-' + name, metrics[name] + 'px');
    set('--keyboard-inset', metrics.inset + 'px');
    html.toggleAttribute('data-compact-viewport', metrics.compact);
    if (pinned && messages.isConnected) messages.scrollTop = messages.scrollHeight;
    win.dispatchEvent(new win.Event('lyra:viewportchange'));
  }
  function schedule() { if (!frame && !disposed) frame = win.requestAnimationFrame(update); }
  const listeners = [[win, 'resize'], [win, 'orientationchange'], [win, 'pageshow'], [doc, 'focusin'], [doc, 'focusout']];
  if (visual) listeners.push([visual, 'resize'], [visual, 'scroll']);
  for (const [target, type] of listeners) target.addEventListener(type, schedule, { passive: true });
  const observer = root ? new win.MutationObserver(schedule) : null;
  observer?.observe(root, { childList: true });
  update();
  return () => {
    disposed = true;
    if (frame) win.cancelAnimationFrame(frame);
    observer?.disconnect();
    for (const [target, type] of listeners) target.removeEventListener(type, schedule);
  };
}
