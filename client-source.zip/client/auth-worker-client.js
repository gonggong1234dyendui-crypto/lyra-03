import * as pgp from 'openpgp';
import {CRYPTO_CONFIG} from './crypto.js';
import {cryptoClockSample} from './crypto-clock.js';

const messages={MEMORY:'设备可用内存不足，请关闭其他标签页后重试。',PASSPHRASE:'口令不正确，请核对后重试。',CHALLENGE:'身份验证已失效，请检查设备自动时间后重试。',UNSUPPORTED:'此浏览器无法运行所需加密功能，请更新 Safari 或系统后重试。',CRYPTO:'本机加密计算未完成，请重试。'};
const cancelled=()=>new DOMException('已取消本次计算，可以重新尝试。','AbortError');
export function runAuthCrypto(operation,args,{signal,timeoutMs=120000,workerFactory=(url,options)=>new Worker(url,options)}={}){
 return new Promise((resolve,reject)=>{
  if(signal?.aborted){reject(cancelled());return}
  let worker,timer,settled=false;
  const finish=(error,result)=>{
   if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);
   if(worker){worker.onmessage=worker.onerror=worker.onmessageerror=null;worker.terminate()}
   error?reject(error):resolve(result);
  };
  const abort=()=>finish(cancelled());
  try{
   if(!['create','unlock','sign'].includes(operation)||!Array.isArray(args))throw new Error('未知的本机加密操作。');
   worker=workerFactory(new URL('./auth-worker.js',import.meta.url),{type:'module',name:'LYRA local account keys'});
   const id=crypto.randomUUID();
   worker.onmessage=({data})=>{if(data?.id!==id)return;if(data.ok===true)finish(null,data.result);else finish(new Error(messages[data.code]||messages.CRYPTO))};
   worker.onerror=event=>{event.preventDefault?.();finish(new Error('本机加密组件无法启动，请刷新页面或更新 Safari 后重试。'))};
   worker.onmessageerror=()=>finish(new Error('本机加密组件返回无效结果，请重试。'));
   timer=setTimeout(()=>finish(new Error('本机加密计算超过两分钟，已安全停止。请关闭其他标签页后重试。')),timeoutMs);
   signal?.addEventListener('abort',abort,{once:true});
   worker.postMessage({id,operation,args,serverTime:cryptoClockSample(),sampledAt:Date.now()});
  }catch{finish(new Error('本机加密组件不可用，请更新浏览器后重试。'))}
 });
}

async function restoreLocalKey(armor,signal){
 signal?.throwIfAborted();
 if(typeof armor!=='string'||armor.length>32768)throw new Error('本机密钥结果无效。');
 const key=await pgp.readPrivateKey({armoredKey:armor,config:CRYPTO_CONFIG});
 signal?.throwIfAborted();
 if(key.keyPacket.version!==6||!key.isDecrypted())throw new Error('本机密钥格式无效。');
 return key;
}
export async function createIdentityForAuth(passphrase,options={}){
 const result=await runAuthCrypto('create',[passphrase],options);
 const privateKey=await restoreLocalKey(result?.privateKeyArmored,options.signal);
 if(typeof result.publicKey!=='string'||typeof result.encryptedPrivateKey!=='string'||privateKey.getFingerprint()!==result.fingerprint)throw new Error('本机身份结果无效。');
 return {privateKey,publicKey:result.publicKey,encryptedPrivateKey:result.encryptedPrivateKey,fingerprint:result.fingerprint};
}
export async function unlockIdentityForAuth(armor,passphrase,options={}){
 const result=await runAuthCrypto('unlock',[armor,passphrase],options);
 return restoreLocalKey(result?.privateKeyArmored,options.signal);
}
export async function signChallengeForAuth(key,text,expected,options={}){
 const result=await runAuthCrypto('sign',[key.armor(),text,expected],options);
 options.signal?.throwIfAborted();
 if(typeof result!=='string'||result.length>16384)throw new Error('本机签名结果无效。');
 return result;
}
