import {fingerprint} from './crypto.js';
import {createIdentityForAuth,unlockIdentityForAuth,signChallengeForAuth} from './auth-worker-client.js';
import {VERSION} from './legal.js';
import {syncCryptoClock} from './crypto-clock.js';

// One attempt owns one identity. A lost response must never create another key
// or strand an already-created numeric account on a subsequent retry.
export function createAuthFlow({registering,request,onStep=async()=>{},onAccount=()=>{},assertActive=()=>{}}) {
 let pendingIdentity,registeredAccount,attemptSignal;
 const timedRequest=async(path,options={})=>{
  const {readResponse,...requestOptions}=options;
  const controller=new AbortController();
  const cancel=()=>controller.abort();
  if(attemptSignal?.aborted)throw new DOMException('已取消本次操作。','AbortError');
  attemptSignal?.addEventListener('abort',cancel,{once:true});
  const timer=setTimeout(()=>controller.abort(),45000);
  try{const response=await request(path,{...requestOptions,signal:controller.signal});return readResponse?await readResponse(response):response}
  catch(error){if(attemptSignal?.aborted)throw new DOMException('已取消本次操作。','AbortError');if(controller.signal.aborted)throw new Error('连接等待超时。请检查网络后重试；不会重复创建账号。');throw error}
  finally{clearTimeout(timer);attemptSignal?.removeEventListener('abort',cancel)}
 };
 const call=(path,body)=>timedRequest(path,{method:'POST',body});
 return {
  get hasIdentity(){return !!pendingIdentity},
  get account(){return registeredAccount},
  async run(passphrase,inputAccount,{signal}={}){
   attemptSignal=signal;
   await onStep('正在检查安全连接…');assertActive();
   const clockStart=Date.now(),health=await timedRequest('/health',{raw:true,readResponse:async response=>({body:await response.json(),date:response.headers?.get('date')})});assertActive();
   const healthBody=health.body;
   if(healthBody?.service!=='LYRA-03'||healthBody.ok!==true)throw new Error('无法确认安全服务器，请重新打开固定网址。');
   const serverTime=healthBody.serverTime===undefined?Date.parse(health.date):healthBody.serverTime;
   syncCryptoClock(serverTime,{startedAt:clockStart,receivedAt:Date.now()});
   let account,identity;
   if(registering){
    if(!pendingIdentity){
     await onStep('正在本机保护密钥… 页面可以继续滚动，最长等待两分钟。',{cancellable:true});assertActive();
     pendingIdentity=await createIdentityForAuth(passphrase,{signal});assertActive();
    }
    identity=pendingIdentity;
    if(!registeredAccount){
     await onStep('正在保存加密账号…');assertActive();
     const result=await call('/api/register',{publicKey:identity.publicKey,encryptedPrivateKey:identity.encryptedPrivateKey,termsVersion:VERSION,privacyVersion:VERSION});
     registeredAccount=result.id;
     onAccount(registeredAccount);
     assertActive();
    }
    account=registeredAccount;
   }else{
    account=inputAccount.replace(/\s/g,'');
    if(!/^\d{20}$/.test(account))throw new Error('请输入完整的 20 位数字号');
    await onStep('正在获取加密密钥…');assertActive();
    const backup=await call('/api/challenge',{id:account});assertActive();
    await onStep('正在本机解锁… 口令不会发送给服务器。',{cancellable:true});assertActive();
    identity={privateKey:await unlockIdentityForAuth(backup.encryptedPrivateKey,passphrase,{signal}),publicKey:backup.publicKey,encryptedPrivateKey:backup.encryptedPrivateKey};
    assertActive();
    if(await fingerprint(identity.publicKey)!==identity.privateKey.getFingerprint())throw new Error('账号公钥与私钥不匹配，已停止登录');
   }
   // Get the short-lived challenge AFTER the expensive mobile key work.
   await onStep('正在验证身份并进入…');assertActive();
   const challenge=await call('/api/challenge',{id:account});assertActive();
   if(challenge.publicKey!==identity.publicKey||challenge.encryptedPrivateKey!==identity.encryptedPrivateKey)throw new Error('账号密钥发生变化，已停止登录。');
   await onStep('正在本机确认身份…',{cancellable:true});assertActive();
   const signature=await signChallengeForAuth(identity.privateKey,challenge.challenge,{id:account,challengeId:challenge.challengeId},{signal});assertActive();
   await onStep('正在建立安全会话…');assertActive();
   const login=await call('/api/login',{id:account,challengeId:challenge.challengeId,signature,deviceName:/Mobi|Android|iPhone/.test(navigator.userAgent)?'手机浏览器':'电脑浏览器'});
   return {account,identity,login};
  },
  clear(){pendingIdentity=undefined}
 };
}
