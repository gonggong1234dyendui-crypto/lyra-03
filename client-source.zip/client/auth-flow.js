import {createIdentity,unlockIdentity,signChallenge,fingerprint} from './crypto.js';
import {VERSION} from './legal.js';

// One attempt owns one identity. A lost response must never create another key
// or strand an already-created numeric account on a subsequent retry.
export function createAuthFlow({registering,request,onStep=async()=>{},onAccount=()=>{},assertActive=()=>{}}) {
 let pendingIdentity,registeredAccount;
 const timedRequest=async(path,options={})=>{
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),45000);
  try{return await request(path,{...options,signal:controller.signal})}
  catch(error){if(controller.signal.aborted)throw new Error('连接等待超时。请检查网络后重试；不会重复创建账号。');throw error}
  finally{clearTimeout(timer)}
 };
 const call=(path,body)=>timedRequest(path,{method:'POST',body});
 return {
  get hasIdentity(){return !!pendingIdentity},
  get account(){return registeredAccount},
  async run(passphrase,inputAccount){
   await onStep('正在检查安全连接…');assertActive();
   const clockStart=Date.now(),health=await timedRequest('/health',{raw:true});assertActive();
   const serverTime=Date.parse(health.headers?.get('date'));
   if(Number.isFinite(serverTime)&&Math.abs(serverTime-(clockStart+Date.now())/2)>30000)throw new Error('手机或电脑的时间与服务器不一致。请打开系统“自动设置日期与时间”后重试。');
   let account,identity;
   if(registering){
    if(!pendingIdentity){
     await onStep('正在本机保护密钥… 首次创建可能需要一些时间，请保持页面打开。');assertActive();
     pendingIdentity=await createIdentity(passphrase);assertActive();
    }
    identity=pendingIdentity;
    if(!registeredAccount){
     await onStep('正在保存加密账号…');assertActive();
     const result=await call('/api/register',{publicKey:identity.publicKey,encryptedPrivateKey:identity.encryptedPrivateKey,termsVersion:VERSION,privacyVersion:VERSION});
     assertActive();registeredAccount=result.id;
     onAccount(registeredAccount);
    }
    account=registeredAccount;
   }else{
    account=inputAccount.replace(/\s/g,'');
    if(!/^\d{20}$/.test(account))throw new Error('请输入完整的 20 位数字号');
    await onStep('正在获取加密密钥…');assertActive();
    const backup=await call('/api/challenge',{id:account});assertActive();
    await onStep('正在本机解锁… 口令不会发送给服务器。');assertActive();
    identity={privateKey:await unlockIdentity(backup.encryptedPrivateKey,passphrase),publicKey:backup.publicKey,encryptedPrivateKey:backup.encryptedPrivateKey};
    assertActive();
    if(await fingerprint(identity.publicKey)!==identity.privateKey.getFingerprint())throw new Error('账号公钥与私钥不匹配，已停止登录');
   }
   // Get the short-lived challenge AFTER the expensive mobile key work.
   await onStep('正在验证身份并进入…');assertActive();
   const challenge=await call('/api/challenge',{id:account});assertActive();
   if(challenge.publicKey!==identity.publicKey||challenge.encryptedPrivateKey!==identity.encryptedPrivateKey)throw new Error('账号密钥发生变化，已停止登录。');
   const signature=await signChallenge(identity.privateKey,challenge.challenge,{id:account,challengeId:challenge.challengeId});assertActive();
   const login=await call('/api/login',{id:account,challengeId:challenge.challengeId,signature,deviceName:/Mobi|Android|iPhone/.test(navigator.userAgent)?'手机浏览器':'电脑浏览器'});
   return {account,identity,login};
  },
  clear(){pendingIdentity=undefined}
 };
}
