// TLS server time is used only as a bounded, in-memory clock correction.
// It is not a source of keys, randomness or permission to skip verification.
const MAX_SKEW_MS=30000, SIGNING_MARGIN_MS=2000;
const clockError=()=>new Error('手机或电脑的时间与服务器不一致。请打开系统“自动设置日期与时间”后重试。');

export function createCryptoClock({wallNow=()=>Date.now(),monotonicNow=()=>performance.now()}={}){
 let anchor;
 return {
  get active(){return !!anchor},
  sync(serverTime,{startedAt,receivedAt=wallNow()}={}){
   if(!Number.isFinite(serverTime)||!Number.isFinite(receivedAt)||Math.abs(serverTime-receivedAt)>MAX_SKEW_MS)throw clockError();
   if(startedAt!==undefined&&(!Number.isFinite(startedAt)||receivedAt<startedAt||receivedAt-startedAt>45000))throw clockError();
   anchor={serverTime,wall:receivedAt,monotonic:monotonicNow()};
  },
  now(){
   if(!anchor)return wallNow();
   const elapsed=monotonicNow()-anchor.monotonic,wallElapsed=wallNow()-anchor.wall;
   // Some mobile clocks pause while asleep. Do not silently use a stale clock
   // after suspension or a large manual clock adjustment; re-unlock resyncs it.
   if(elapsed<0||Math.abs(wallElapsed-elapsed)>MAX_SKEW_MS)throw new Error('设备休眠或时间发生变化，请重新解锁以同步安全时间。');
   return anchor.serverTime+elapsed;
  },
  clear(){anchor=undefined},
 };
}

const clock=createCryptoClock();
export const syncCryptoClock=(serverTime,options)=>clock.sync(serverTime,options);
export const cryptoNow=()=>clock.now();
export const cryptoDate=()=>new Date(clock.now());
export const cryptoClockSample=()=>clock.active?clock.now():undefined;
export function cryptoSigningDate(keys=[]){
 const now=clock.now();
 // OpenPGP stores whole-second dates. A small conservative margin avoids a
 // just-issued signature appearing in the future after transport/rounding.
 let time=now-(clock.active?SIGNING_MARGIN_MS:0);
 for(const key of keys)for(const part of key.getKeys())time=Math.max(time,part.getCreationTime().getTime());
 if(time>now)throw new Error('密钥创建时间尚未到达，请稍后在此页面重试。');
 return new Date(time);
}
