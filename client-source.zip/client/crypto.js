import * as pgp from 'openpgp';

// RFC 9580 OpenPGP packets; application code does not construct a cipher/protocol.
export const CRYPTO_CONFIG = Object.freeze({
  v6Keys: true,
  aeadProtect: true,
  preferredSymmetricAlgorithm: pgp.enums.symmetric.aes256,
  preferredAEADAlgorithm: pgp.enums.aead.gcm,
  preferredCompressionAlgorithm: pgp.enums.compression.uncompressed,
  aeadChunkSizeByte: 12,
  s2kType: pgp.enums.s2k.argon2,
  s2kArgon2Params: { passes: 3, parallelism: 1, memoryExponent: 16 },
  maxArgon2MemoryExponent: 16,
});

const textEncoder = new TextEncoder();
const publicCache = new Map();
const MAX_TEXT = 128 * 1024;
const MAX_ARMOR = 200 * 1024;
const ACCOUNT = /^\d{20}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function requireAEAD(message) {
  if (![...message.packets].some(packet => packet.constructor.tag === pgp.enums.packet.symEncryptedIntegrityProtectedData && packet.version === 2)) throw new Error('拒绝降级：LYRA 仅接收 RFC 9580 AEAD 密文。');
  return message;
}

function passphraseCheck(passphrase) {
  if (typeof passphrase !== 'string' || [...passphrase].length < 14 || textEncoder.encode(passphrase).length > 512) {
    throw new Error('请使用至少 14 个字符、最多 512 字节的独立长密码。');
  }
}

export async function createIdentity(passphrase) {
  passphraseCheck(passphrase);
  // Keep the newly generated key in client memory and encrypt a clone for its
  // backup. OpenPGP.encryptKey does not mutate the original. This avoids doing
  // the expensive Argon2 derivation again just to unlock the key we generated.
  const { privateKey, publicKey } = await pgp.generateKey({ type: 'curve25519', userIDs: [{ name: 'LYRA-03' }], format: 'object', config: CRYPTO_CONFIG });
  try {
    const protectedKey = await pgp.encryptKey({ privateKey, passphrase, config: CRYPTO_CONFIG });
    if (!privateKey.getKeys().every(({ keyPacket }) => keyPacket.isDecrypted()) || protectedKey.getKeys().some(({ keyPacket }) => keyPacket.isDecrypted()) || privateKey.getFingerprint() !== protectedKey.getFingerprint()) {
      throw new Error('无法安全保护账号密钥，请重试。');
    }
    return { publicKey: publicKey.armor(), encryptedPrivateKey: protectedKey.armor(), privateKey, fingerprint: privateKey.getFingerprint() };
  } catch (error) {
    privateKey.clearPrivateParams();
    throw error;
  }
}

export async function unlockIdentity(encryptedPrivateKey, passphrase) {
  if (typeof encryptedPrivateKey !== 'string' || encryptedPrivateKey.length > 32768) throw new Error('密钥备份格式不正确。');
  if (typeof passphrase !== 'string' || textEncoder.encode(passphrase).length > 512) throw new Error('密码格式不正确。');
  const key = await pgp.readPrivateKey({ armoredKey: encryptedPrivateKey, config: CRYPTO_CONFIG });
  if (key.keyPacket.version !== 6 || key.isDecrypted()) throw new Error('需要受密码保护的 LYRA v6 私钥。');
  return pgp.decryptKey({ privateKey: key, passphrase, config: CRYPTO_CONFIG });
}

export async function readPublic(armoredKey) {
  if (typeof armoredKey !== 'string' || armoredKey.length > 32768) throw new Error('公钥格式不正确。');
  if (publicCache.has(armoredKey)) return publicCache.get(armoredKey);
  const key = await pgp.readKey({ armoredKey, config: CRYPTO_CONFIG });
  if (key.isPrivate() || key.keyPacket.version !== 6) throw new Error('需要 LYRA v6 公钥。');
  await key.verifyPrimaryKey();
  await key.getEncryptionKey();
  if (publicCache.size >= 32) publicCache.delete(publicCache.keys().next().value);
  publicCache.set(armoredKey, key);
  return key;
}

export async function fingerprint(publicKey) { return (await readPublic(publicKey)).getFingerprint(); }

export async function signChallenge(privateKey, text, expected) {
  // Sign only this service's exact login envelope, never arbitrary server text.
  const match = typeof text === 'string' && text.length <= 512 && /^LYRA-03 login\nAccount: ([1-9]\d{19})\nChallenge: ([0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})\nNonce: ([A-Za-z0-9_-]{43})\nExpires: (\d{13})$/.exec(text);
  if (!match || match[0] !== text || !expected || match[1] !== expected.id || match[2] !== expected.challengeId) throw new Error('登录挑战身份或格式无效。');
  const expires = Number(match[4]), now = Date.now();
  // Server TTL is 60 s; tolerate at most 30 s clock skew, never an unlimited challenge.
  if (!Number.isSafeInteger(expires) || expires < now - 30000 || expires > now + 90000) throw new Error('登录挑战已失效，或设备时间不准确，请重新解锁。');
  return pgp.sign({ message: await pgp.createMessage({ text }), signingKeys: privateKey, detached: true, format: 'armored', config: CRYPTO_CONFIG });
}

export function validatePayload(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload) || payload.v !== 1 || !ACCOUNT.test(payload.from) || !ACCOUNT.test(payload.to) || !UUID.test(payload.clientId)) throw new Error('消息身份字段无效。');
  if (!['text', 'file', 'receipt'].includes(payload.type) || !Number.isSafeInteger(payload.at) || payload.at <= 0) throw new Error('消息格式无效。');
  if (payload.type === 'text' && (typeof payload.text !== 'string' || payload.text.length > 16000)) throw new Error('消息文字无效或过长。');
  if (payload.type === 'file' && (!payload.file || typeof payload.file !== 'object')) throw new Error('文件消息无效。');
  if (payload.type === 'receipt' && !Number.isSafeInteger(payload.messageId)) throw new Error('回执无效。');
  return payload;
}

// These helpers are also used for a signed, encrypted local transfer descriptor.
export async function sealJson(privateKey, recipientArmors, value) {
  const text = JSON.stringify(value);
  if (textEncoder.encode(text).length > MAX_TEXT) throw new Error('消息内容过长。');
  const encryptionKeys = await Promise.all([...new Set(recipientArmors)].map(readPublic));
  if (!encryptionKeys.length || encryptionKeys.length > 2) throw new Error('仅支持双方私密通信。');
  return pgp.encrypt({ message: await pgp.createMessage({ text }), encryptionKeys, signingKeys: privateKey, format: 'armored', config: CRYPTO_CONFIG });
}

export async function unsealJson(privateKey, senderArmor, ciphertext) {
  if (typeof ciphertext !== 'string' || ciphertext.length > MAX_ARMOR) throw new Error('加密消息大小无效。');
  const result = await pgp.decrypt({
    message: requireAEAD(await pgp.readMessage({ armoredMessage: ciphertext, config: CRYPTO_CONFIG })),
    decryptionKeys: privateKey, verificationKeys: await readPublic(senderArmor), expectSigned: true, format: 'utf8',
    config: { ...CRYPTO_CONFIG, maxDecompressedMessageSize: MAX_TEXT },
  });
  if (!result.signatures.length) throw new Error('消息缺少发送者签名。');
  await Promise.all(result.signatures.map(signature => signature.verified));
  if (typeof result.data !== 'string' || textEncoder.encode(result.data).length > MAX_TEXT) throw new Error('解密消息过长。');
  return JSON.parse(result.data);
}

export async function encryptPayload(privateKey, recipientArmors, payload) { return sealJson(privateKey, recipientArmors, validatePayload(payload)); }
export async function decryptPayload(privateKey, senderArmor, ciphertext) { return validatePayload(await unsealJson(privateKey, senderArmor, ciphertext)); }

export async function encryptFileStream(privateKey, recipientArmors, stream) {
  const encryptionKeys = await Promise.all([...new Set(recipientArmors)].map(readPublic));
  if (!encryptionKeys.length || encryptionKeys.length > 2) throw new Error('文件收件人无效。');
  return pgp.encrypt({ message: await pgp.createMessage({ binary: stream, filename: '' }), encryptionKeys, signingKeys: privateKey, format: 'binary', config: CRYPTO_CONFIG });
}

export async function decryptFileStream(privateKey, senderArmor, stream) {
  const result = await pgp.decrypt({
    message: requireAEAD(await pgp.readMessage({ binaryMessage: stream, config: CRYPTO_CONFIG })),
    decryptionKeys: privateKey, verificationKeys: await readPublic(senderArmor), expectSigned: true, format: 'binary',
    config: { ...CRYPTO_CONFIG, maxDecompressedMessageSize: 5 * 1024 ** 3 },
  });
  // Consume the stream before awaiting verification; its signature is at the end.
  // Consumers must not display or commit a destination before verify() resolves.
  return { stream: result.data, verify: async () => {
    if (!result.signatures.length) throw new Error('文件缺少发送者签名。');
    await Promise.all(result.signatures.map(signature => signature.verified));
  } };
}
