import { encryptFileStream, decryptFileStream, sealJson, unsealJson, fingerprint } from './crypto.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { bytesToHex } from '@noble/hashes/utils.js';

export const CHUNK_BYTES = 4 * 1024 ** 2;
export const MAX_FILE_BYTES = 5 * 1024 ** 3;
export const MOBILE_BLOB_LIMIT = 128 * 1024 ** 2;
const DB_NAME = 'lyra03-encrypted-transfers-v1';
const SPOOL_NAME = 'lyra03-ciphertext';
const DOWNLOAD_NAME = 'lyra03-verified-downloads';
const liveDownloads = new Map();
let database;

function cancelled(signal) { signal?.throwIfAborted(); }
function progress(fn, phase, loaded, total) { fn?.({ phase, loaded, total, percent: total ? Math.min(100, Math.floor(100 * loaded / total)) : 0 }); }
function timeout(ms, signal) {
  return new Promise((resolve, reject) => {
    cancelled(signal);
    const timer = setTimeout(done, ms);
    function done() { signal?.removeEventListener('abort', abort); resolve(); }
    function abort() { clearTimeout(timer); signal?.removeEventListener('abort', abort); reject(signal.reason || new DOMException('已取消', 'AbortError')); }
    signal?.addEventListener('abort', abort, { once: true });
  });
}

async function retry(operation, signal) {
  for (let attempt = 0; ; attempt++) {
    cancelled(signal);
    try { return await operation(); } catch (error) {
      if (signal?.aborted || error?.name === 'AbortError' || attempt >= 4 || (error.status >= 400 && error.status < 500 && ![408, 429].includes(error.status))) throw error;
      await timeout(Math.min(8000, 500 * 2 ** attempt) + Math.random() * 150, signal);
    }
  }
}

function db() {
  if (!database) database = new Promise((resolve, reject) => {
    const open = indexedDB.open(DB_NAME, 1);
    open.onupgradeneeded = () => { open.result.createObjectStore('jobs', { keyPath: 'id' }); open.result.createObjectStore('chunks'); };
    open.onsuccess = () => resolve(open.result);
    open.onerror = () => { database = null; reject(open.error); };
  });
  return database;
}

async function store(storeName, mode, callback) {
  const connection = await db();
  return new Promise((resolve, reject) => {
    const tx = connection.transaction(storeName, mode), request = callback(tx.objectStore(storeName));
    tx.oncomplete = () => resolve(request?.result);
    tx.onerror = () => reject(tx.error || request?.error);
    tx.onabort = () => reject(tx.error || new Error('本地加密缓存写入失败。'));
  });
}

function safeJobId(id) { if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error('传输任务编号无效。'); return id; }
async function jobDir(id, create = false) {
  const root = await navigator.storage.getDirectory();
  return (await root.getDirectoryHandle(SPOOL_NAME, { create })).getDirectoryHandle(safeJobId(id), { create });
}
async function supportsOpfsWriter() {
  if (!globalThis.navigator?.storage?.getDirectory) return false;
  let root, name, writable;
  try {
    root = await navigator.storage.getDirectory(); name = `lyra03-probe-${crypto.randomUUID()}`;
    const file = await root.getFileHandle(name, { create: true });
    if (typeof file.createWritable !== 'function') return false;
    writable = await file.createWritable(); await writable.abort(); writable = null;
    return true;
  } catch { return false; }
  finally { await writable?.abort().catch(() => {}); if (root && name) await root.removeEntry(name).catch(() => {}); }
}
async function selectStorage(id) {
  if (await supportsOpfsWriter()) {
    try { await jobDir(id, true); return 'opfs'; } catch (error) { if (error.name === 'QuotaExceededError') throw error; }
  }
  if (!globalThis.indexedDB) throw new Error('此浏览器不支持安全文件缓存，请使用更新版本的 Safari、Chrome 或 Edge。');
  await db();
  return 'idb';
}

function validDownloadId(id) { return /^\d{13}-[a-f0-9-]{36}$/.test(id); }
async function downloadRoot(create = false) { return (await navigator.storage.getDirectory()).getDirectoryHandle(DOWNLOAD_NAME, { create }); }

async function acquireDownloadLease(id) {
  if (!navigator.locks?.request) return () => {};
  let release, acquired, rejected;
  const ready = new Promise((resolve, reject) => { acquired = resolve; rejected = reject; });
  const held = new Promise(resolve => { release = resolve; });
  navigator.locks.request(`lyra03-download:${id}`, { mode: 'exclusive' }, async () => { acquired(); await held; }).catch(rejected);
  await ready; return release;
}

async function temporaryDownload() {
  if (!await supportsOpfsWriter()) return null;
  const id = `${Date.now()}-${crypto.randomUUID()}`, release = await acquireDownloadLease(id);
  let directory;
  const cleanup = async () => {
    try { await (await downloadRoot()).removeEntry(id, { recursive: true }); }
    catch (error) { if (error.name !== 'NotFoundError') throw error; }
    finally { liveDownloads.delete(id); release(); }
  };
  try {
    directory = await (await downloadRoot(true)).getDirectoryHandle(id, { create: true });
    const handle = await directory.getFileHandle('content.bin', { create: true });
    liveDownloads.set(id, cleanup);
    return { handle, cleanup };
  } catch (error) { await cleanup().catch(() => {}); throw error; }
}

// Call on startup. A live transfer holds a Web Lock across tabs; an abandoned
// transfer loses its lock automatically when its page/browser terminates.
export async function cleanupStaleDownloads() {
  if (!globalThis.navigator?.storage?.getDirectory) return;
  let root;
  try { root = await downloadRoot(); } catch (error) { if (error.name === 'NotFoundError') return; throw error; }
  for await (const [id, entry] of root.entries()) {
    if (entry.kind !== 'directory' || !validDownloadId(id) || liveDownloads.has(id)) continue;
    const remove = () => root.removeEntry(id, { recursive: true }).catch(error => { if (error.name !== 'NotFoundError') throw error; });
    if (navigator.locks?.request) await navigator.locks.request(`lyra03-download:${id}`, { ifAvailable: true, mode: 'exclusive' }, async lock => { if (lock) await remove(); });
    else if (Number(id.slice(0, 13)) < Date.now() - 24 * 60 * 60 * 1000) await remove();
  }
}

// Explicit lock/exit should also call this; page termination may interrupt an
// async cleanup, in which case the next startup handles the abandoned directory.
export async function cleanupActiveDownloads() {
  await Promise.allSettled([...liveDownloads.values()].map(cleanup => cleanup()));
}
async function putChunk(job, index, bytes) {
  if (job.storage === 'opfs') {
    const handle = await (await jobDir(job.id, true)).getFileHandle(String(index), { create: true });
    const writable = await handle.createWritable();
    try { await writable.write(bytes); await writable.close(); } catch (error) { await writable.abort().catch(() => {}); throw error; }
  } else await store('chunks', 'readwrite', records => records.put(bytes, [job.id, index]));
}
async function getChunk(job, index) {
  if (job.storage === 'opfs') return new Uint8Array(await (await (await jobDir(job.id)).getFileHandle(String(index))).getFile().then(file => file.arrayBuffer()));
  const bytes = await store('chunks', 'readonly', records => records.get([job.id, index]));
  if (!(bytes instanceof Uint8Array)) throw new Error('本地加密文件缓存已被浏览器清理，请重新选择文件。');
  return bytes;
}
async function saveJob(job) {
  // Clear filenames, MIME types, and identity keys never enter the local spool index.
  const { name, size, type, lastModified, recipients, to, ...encryptedRecord } = job;
  await store('jobs', 'readwrite', records => records.put(encryptedRecord));
}

export async function persistPreparedEnvelope(job, ciphertext) {
  if (!job.ready || typeof ciphertext !== 'string' || ciphertext.length > 200 * 1024 || !ciphertext.startsWith('-----BEGIN PGP MESSAGE-----')) throw new Error('文件消息密文无效。');
  if (job.envelope && job.envelope !== ciphertext) throw new Error('文件消息密文已固定，重试必须使用原密文。');
  job.envelope = ciphertext; await saveJob(job); return ciphertext;
}

export async function listPreparedFiles({ privateKey, ownPublicKey }) {
  const records = await store('jobs', 'readonly', jobs => jobs.getAll()), owner = privateKey.getFingerprint(), jobs = [];
  for (const job of records) {
    if (job.owner !== owner || !job.ready) continue;
    try {
      const descriptor = await unsealJson(privateKey, ownPublicKey, job.descriptor);
      if (descriptor.schema === 'LYRA-03:spool:v1' && descriptor.id === job.id && descriptor.owner === owner) jobs.push({ ...job, ...descriptor.metadata });
    } catch { /* Another account or a damaged descriptor is not exposed. */ }
  }
  return jobs;
}

export async function removePreparedFile(job) {
  safeJobId(job.id);
  if (job.storage === 'opfs') {
    try { const root = await navigator.storage.getDirectory(); await (await root.getDirectoryHandle(SPOOL_NAME)).removeEntry(job.id, { recursive: true }); }
    catch (error) { if (error.name !== 'NotFoundError') throw error; }
  } else {
    const connection = await db();
    await new Promise((resolve, reject) => {
      const tx = connection.transaction('chunks', 'readwrite');
      tx.objectStore('chunks').delete(IDBKeyRange.bound([job.id, 0], [job.id, Number.MAX_SAFE_INTEGER]));
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
    });
  }
  await store('jobs', 'readwrite', records => records.delete(job.id));
}

export async function prepareFile(file, { privateKey, recipients, to, onProgress, signal }) {
  cancelled(signal);
  if (!file || !Number.isSafeInteger(file.size) || file.size < 0 || file.size > MAX_FILE_BYTES) throw new Error('单个文件最大为 5 GB。');
  if (!file.stream) throw new Error('当前浏览器不支持流式读取文件。');
  if (!/^\d{20}$/.test(to)) throw new Error('请先选择文件接收人。');
  const estimate = await globalThis.navigator?.storage?.estimate?.().catch(() => null);
  if (estimate?.quota && estimate.quota - estimate.usage < file.size * 1.03 + CHUNK_BYTES * 2) throw new Error('浏览器可用缓存不足。请释放空间或换用电脑浏览器。');
  const id = crypto.randomUUID(), owner = privateKey.getFingerprint();
  const metadata = { name: String(file.name || '文件').slice(0, 240), size: file.size, type: String(file.type || 'application/octet-stream').slice(0, 120), lastModified: file.lastModified || 0, to };
  const messageClientId = crypto.randomUUID();
  const job = { id, owner, createdAt: Date.now(), storage: await selectStorage(id), totalChunks: 0, cipherBytes: 0, ready: false, messageClientId, clientId: messageClientId, ...metadata };
  job.descriptor = await sealJson(privateKey, recipients, { schema: 'LYRA-03:spool:v1', id, owner, metadata, recipients: await Promise.all(recipients.map(fingerprint)) });
  let plainBytes = 0, reader; const hash = sha256.create();
  try {
    await saveJob(job);
    const input = file.stream().pipeThrough(new TransformStream({ transform(bytes, controller) {
      cancelled(signal); plainBytes += bytes.byteLength; controller.enqueue(bytes); progress(onProgress, 'encrypt', plainBytes, file.size);
    } }));
    reader = (await encryptFileStream(privateKey, recipients, input)).getReader();
    let pending = new Uint8Array(CHUNK_BYTES), used = 0;
    for (;;) {
      cancelled(signal);
      const { done, value } = await reader.read(); if (done) break;
      hash.update(value);
      for (let offset = 0; offset < value.length;) {
        const take = Math.min(CHUNK_BYTES - used, value.length - offset);
        pending.set(value.subarray(offset, offset + take), used); used += take; offset += take;
        if (used === CHUNK_BYTES) { await putChunk(job, job.totalChunks++, pending); job.cipherBytes += used; used = 0; pending = new Uint8Array(CHUNK_BYTES); }
      }
    }
    if (used) { await putChunk(job, job.totalChunks++, pending.slice(0, used)); job.cipherBytes += used; }
    job.sha256 = bytesToHex(hash.digest()); job.ready = true; await saveJob(job); progress(onProgress, 'encrypt', file.size, file.size);
    return job;
  } catch (error) {
    await reader?.cancel(error).catch(() => {}); await removePreparedFile(job).catch(() => {});
    if (error.name === 'QuotaExceededError') throw new Error('浏览器缓存空间不足，加密任务已安全取消。');
    throw error;
  } finally { reader?.releaseLock(); }
}

export async function uploadFile(job, { request, to, clientId, onProgress, signal }) {
  cancelled(signal);
  if (!job.ready || !job.totalChunks || !/^\d{20}$/.test(to)) throw new Error('文件任务尚未准备完成。');
  if (job.to && (job.to !== to || job.clientId !== clientId)) throw new Error('恢复传输时收件人和消息编号必须保持不变。');
  job.to = to; job.clientId = clientId;
  if (!job.uploadId) {
    const created = await retry(() => request('/api/files', { method: 'POST', body: { to, clientId, totalChunks: job.totalChunks, cipherBytes: job.cipherBytes }, signal }), signal);
    if (created.chunkBytes !== CHUNK_BYTES || typeof created.id !== 'string') throw new Error('服务器文件分块规格不兼容。');
    job.uploadId = created.id; await saveJob(job);
  }
  const status = await retry(() => request(`/api/files/${encodeURIComponent(job.uploadId)}/status`, { signal }), signal);
  if (status.totalChunks !== job.totalChunks || status.cipherBytes !== job.cipherBytes || !Array.isArray(status.received)) throw new Error('服务器文件任务信息不一致。');
  const received = new Set(status.received.filter(index => Number.isInteger(index) && index >= 0 && index < job.totalChunks));
  let loaded = 0;
  for (const index of received) loaded += Math.min(CHUNK_BYTES, job.cipherBytes - index * CHUNK_BYTES);
  progress(onProgress, 'upload', loaded, job.cipherBytes);
  for (let index = 0; index < job.totalChunks; index++) {
    cancelled(signal); if (received.has(index)) continue;
    const bytes = await getChunk(job, index);
    await retry(() => request(`/api/files/${encodeURIComponent(job.uploadId)}/chunks/${index}`, { method: 'PUT', body: bytes, headers: { 'Content-Type': 'application/octet-stream' }, signal }), signal);
    loaded += bytes.byteLength; progress(onProgress, 'upload', loaded, job.cipherBytes);
  }
  await retry(() => request(`/api/files/${encodeURIComponent(job.uploadId)}/complete`, { method: 'POST', body: {}, signal }), signal);
  progress(onProgress, 'complete', job.size, job.size);
  return { id: job.uploadId, name: job.name, size: job.size, type: job.type, totalChunks: job.totalChunks, cipherBytes: job.cipherBytes, chunkBytes: CHUNK_BYTES, sha256: job.sha256 };
}

export function validateManifest(file) {
  if (!file || typeof file.id !== 'string' || !/^[a-zA-Z0-9-]{16,80}$/.test(file.id) || typeof file.name !== 'string' || file.name.length > 240 || typeof file.type !== 'string' || file.type.length > 120) throw new Error('加密文件信息无效。');
  if (typeof file.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(file.sha256)) throw new Error('文件缺少签名清单中的 SHA-256 校验。');
  if (!Number.isSafeInteger(file.size) || file.size < 0 || file.size > MAX_FILE_BYTES || !Number.isSafeInteger(file.cipherBytes) || file.cipherBytes <= 0 || file.cipherBytes > MAX_FILE_BYTES + 64 * 1024 ** 2 || file.chunkBytes !== CHUNK_BYTES || file.totalChunks !== Math.ceil(file.cipherBytes / CHUNK_BYTES)) throw new Error('加密文件大小或分块信息无效。');
  return file;
}

export async function downloadFile(manifest, { privateKey, senderPublicKey, request, onProgress, signal, fileHandle }) {
  const file = validateManifest(manifest); cancelled(signal);
  let temporary = null;
  if (!fileHandle && file.size > MOBILE_BLOB_LIMIT) {
    const estimate = await globalThis.navigator?.storage?.estimate?.().catch(() => null);
    if (estimate?.quota && estimate.quota - estimate.usage < file.size + CHUNK_BYTES * 2) throw new Error('浏览器没有足够的空间暂存这个下载。请释放空间，或在电脑浏览器中直接保存到文件。');
    temporary = await temporaryDownload();
    if (!temporary) throw new Error('此浏览器不支持流式或磁盘暂存下载，安全下载上限为 128 MB。请使用支持磁盘暂存的新版浏览器，或电脑版 Chrome / Edge。');
  }
  let cipherRead = 0, plainRead = 0, index = 0, destination, reader, verified = false; const hash = sha256.create();
  const parts = [];
  const ciphertext = new ReadableStream({ async pull(controller) {
    try {
      cancelled(signal);
      if (index >= file.totalChunks) { if (cipherRead !== file.cipherBytes) throw new Error('密文总长度不匹配。'); controller.close(); return; }
      const currentIndex = index;
      const bytes = await retry(async () => {
        const response = await request(`/api/files/${encodeURIComponent(file.id)}/chunks/${currentIndex}`, { raw: true, signal });
        if (!response.ok) { const error = new Error('文件下载失败。'); error.status = response.status; throw error; }
        const expected = Math.min(CHUNK_BYTES, file.cipherBytes - currentIndex * CHUNK_BYTES);
        const declared = response.headers.get('Content-Length');
        if (declared && Number(declared) !== expected) throw new Error('密文分块长度不匹配。');
        // Each response is capped by the server; check streaming length as well.
        const binary = new Uint8Array(expected), responseReader = response.body.getReader(); let offset = 0;
        try { for (;;) { const { done, value } = await responseReader.read(); if (done) break; if (offset + value.length > expected) throw new Error('密文分块过长。'); binary.set(value, offset); offset += value.length; } }
        catch (error) { await responseReader.cancel(error).catch(() => {}); throw error; }
        finally { responseReader.releaseLock(); }
        if (offset !== expected) throw new Error('密文分块不完整。');
        return binary;
      }, signal);
      index++; cipherRead += bytes.length; hash.update(bytes); controller.enqueue(bytes); progress(onProgress, 'download', cipherRead, file.cipherBytes);
    } catch (error) { controller.error(error); }
  } }, { highWaterMark: 0 });
  try {
    if (fileHandle || temporary) destination = await (fileHandle || temporary.handle).createWritable();
    const decrypted = await decryptFileStream(privateKey, senderPublicKey, ciphertext);
    reader = decrypted.stream.getReader();
    for (;;) {
      cancelled(signal);
      const { done, value } = await reader.read(); if (done) break;
      plainRead += value.length;
      if (plainRead > file.size) throw new Error('解密后的文件超过授权大小。');
      if (destination) await destination.write(value); else parts.push(value);
    }
    if (plainRead !== file.size) throw new Error('解密文件长度不匹配。');
    if (bytesToHex(hash.digest()) !== file.sha256) throw new Error('文件与加密消息中的校验不一致，拒绝保存。');
    progress(onProgress, 'verify', plainRead, file.size); await decrypted.verify(); cancelled(signal); verified = true;
    if (destination) {
      await destination.close(); destination = null; progress(onProgress, 'complete', file.size, file.size);
      if (temporary) {
        // File is backed by OPFS disk storage; do not arrayBuffer()/collect it.
        // Keep it until the user's save has started and the client locks/exits.
        const diskFile = await temporary.handle.getFile();
        return { saved: false, blob: diskFile, name: file.name, size: file.size, temporaryPlaintext: true, cleanup: temporary.cleanup };
      }
      return { saved: true, name: file.name, size: file.size };
    }
    const blob = new Blob(parts, { type: file.type }); parts.length = 0;
    progress(onProgress, 'complete', file.size, file.size);
    return { saved: false, blob, name: file.name, size: file.size };
  } catch (error) { await reader?.cancel(error).catch(() => {}); await destination?.abort().catch(() => {}); await temporary?.cleanup().catch(() => {}); throw error; }
  finally { reader?.releaseLock(); if (!verified) parts.length = 0; }
}
