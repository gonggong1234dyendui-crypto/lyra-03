import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, randomInt, randomUUID, createHash } from 'node:crypto';
import { mkdir, writeFile, rename, unlink, readdir, stat } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import * as pgp from 'openpgp';

export const POLICY = Object.freeze({termsVersion:'2026-11-05',privacyVersion:'2026-11-05',maxFileBytes:5*1024**3,chunkBytes:4*1024**2});
const JSON_LIMIT=256*1024, CIPHER_LIMIT=200*1024, MAX_CIPHER_BYTES=POLICY.maxFileBytes+32*1024**2;
const hash=b=>createHash('sha256').update(b).digest('hex');
const idPattern=/^[1-9][0-9]{19}$/;
const uuidPattern=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
class HttpError extends Error { constructor(status,message){super(message);this.status=status;} }
const fail=(status,message)=>{throw new HttpError(status,message);};
const check=(condition,status,message)=>{if(!condition)fail(status,message);};
const accountId=value=>{check(typeof value==='string'&&idPattern.test(value),400,'无效的好友号');return value;};
const uuid=value=>{check(typeof value==='string'&&uuidPattern.test(value),400,'无效的请求标识');return value;};
const integer=(value,min,max)=>{check(Number.isSafeInteger(value)&&value>=min&&value<=max,400,'无效的数值');return value;};
const cleanDevice=value=>typeof value==='string'?value.replace(/[\u0000-\u001f\u007f]/g,'').slice(0,60):'浏览器';
const safeString=(value,max)=>typeof value==='string'&&Buffer.byteLength(value,'utf8')<=max;
const loopback=address=>['127.0.0.1','::1','::ffff:127.0.0.1','localhost'].includes(address);

async function body(req,max=JSON_LIMIT,binary=false){
  const len=req.headers['content-length'];
  if(len!==undefined)check(/^\d+$/.test(len)&&Number(len)<=max,413,'请求过大');
  if(!binary)check(/^application\/json(?:;|$)/i.test(req.headers['content-type']||''),415,'需要 JSON 请求');
  const chunks=[];let size=0;
  for await (const chunk of req){size+=chunk.length;check(size<=max,413,'请求过大');chunks.push(chunk);}
  const buffer=Buffer.concat(chunks,size);
  if(binary)return buffer;
  try {const result=JSON.parse(buffer.toString('utf8'));check(result&&typeof result==='object'&&!Array.isArray(result),400,'无效的 JSON');return result;}
  catch(error){if(error instanceof HttpError)throw error;fail(400,'无效的 JSON');}
}

export async function createRelay(options={}){
  const {dataDir,port=0,host='127.0.0.1',staticDir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../dist'),allowedOrigins=['https://gonggong1234dyendui-crypto.github.io'],maxStorageBytes=300*1024**3,maxAccountStorageBytes=30*1024**3,sessionMs=24*60*60*1000,challengeMs=60_000,rateLimits=true}=options;
  if(!dataDir||!loopback(host))throw new Error('LYRA requires its own dataDir and a loopback listener');
  const root=path.resolve(dataDir),filesRoot=path.join(root,'files');
  await mkdir(filesRoot,{recursive:true,mode:0o700});
  const db=new DatabaseSync(path.join(root,'relay.sqlite'));
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=3000;
    CREATE TABLE IF NOT EXISTS accounts(id TEXT PRIMARY KEY,publicKey TEXT NOT NULL,fingerprint TEXT NOT NULL UNIQUE,encryptedPrivateKey TEXT NOT NULL,createdAt INTEGER NOT NULL,termsVersion TEXT NOT NULL,privacyVersion TEXT NOT NULL,consentAt INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY,account TEXT NOT NULL REFERENCES accounts(id),tokenHash TEXT NOT NULL UNIQUE,deviceName TEXT NOT NULL,createdAt INTEGER NOT NULL,lastSeen INTEGER NOT NULL,expiresAt INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS sessions_account ON sessions(account);
    CREATE TABLE IF NOT EXISTS friends(a TEXT NOT NULL REFERENCES accounts(id),b TEXT NOT NULL REFERENCES accounts(id),requestedBy TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('pending','accepted')),createdAt INTEGER NOT NULL,PRIMARY KEY(a,b));
    CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT NOT NULL REFERENCES accounts(id),recipient TEXT NOT NULL REFERENCES accounts(id),clientId TEXT NOT NULL,ciphertext TEXT NOT NULL,createdAt INTEGER NOT NULL,UNIQUE(sender,clientId));
    CREATE INDEX IF NOT EXISTS messages_pair ON messages(sender,recipient,id);
    CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY,owner TEXT NOT NULL REFERENCES accounts(id),recipient TEXT NOT NULL REFERENCES accounts(id),clientId TEXT NOT NULL,totalChunks INTEGER NOT NULL,cipherBytes INTEGER NOT NULL,complete INTEGER NOT NULL DEFAULT 0,createdAt INTEGER NOT NULL,UNIQUE(owner,clientId));
    CREATE TABLE IF NOT EXISTS chunks(fileId TEXT NOT NULL REFERENCES files(id) ON DELETE CASCADE,idx INTEGER NOT NULL,bytes INTEGER NOT NULL,digest TEXT NOT NULL,PRIMARY KEY(fileId,idx));
    CREATE TABLE IF NOT EXISTS security_events(id INTEGER PRIMARY KEY AUTOINCREMENT,event TEXT NOT NULL,createdAt INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS storage_counters(name TEXT PRIMARY KEY,bytes INTEGER NOT NULL);
    INSERT OR IGNORE INTO storage_counters(name,bytes) SELECT 'messages',COALESCE(SUM(length(ciphertext)),0) FROM messages;
  `);
  const statements=new Map();const sql=text=>{if(!statements.has(text))statements.set(text,db.prepare(text));return statements.get(text);};
  const audit=event=>{sql('INSERT INTO security_events(event,createdAt) VALUES (?,?)').run(event,Date.now());sql('DELETE FROM security_events WHERE id < (SELECT COALESCE(MAX(id),0)-2000 FROM security_events)').run();};
  const account=id=>sql('SELECT * FROM accounts WHERE id=?').get(id);
  const profile=row=>({id:row.id,publicKey:row.publicKey,fingerprint:row.fingerprint});
  const pair=(a,b)=>[a,b].sort();
  const relationship=(a,b)=>sql('SELECT * FROM friends WHERE a=? AND b=?').get(...pair(a,b));
  const accepted=(a,b)=>relationship(a,b)?.status==='accepted';
  const message=row=>({id:row.id,from:row.sender,to:row.recipient,clientId:row.clientId,ciphertext:row.ciphertext,createdAt:row.createdAt});
  const challenges=new Map(),buckets=new Map(),sockets=new Map(),uploadLocks=new Set();let cryptoBusy=0,closing=false;
  const origins=new Set(allowedOrigins);
  function rate(key,limit,windowMs){
    if(!rateLimits)return;
    const now=Date.now();let b=buckets.get(key);if(!b||b.until<=now){b={count:0,until:now+windowMs};buckets.set(key,b);}
    check(++b.count<=limit,429,'请求过于频繁，请稍后再试');
    check(buckets.size<=20000,503,'服务器繁忙');
  }
  const peerIP=req=>loopback(req.socket.remoteAddress)&&req.headers['x-forwarded-proto']==='https'&&typeof req.headers['cf-connecting-ip']==='string'?req.headers['cf-connecting-ip'].slice(0,64):req.socket.remoteAddress;
  function transport(req){
    check(loopback(req.socket.remoteAddress),403,'只接受本机安全代理连接');
    check(typeof req.headers.host==='string'&&req.headers.host.length<=260&&/^(?:[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?|\[[0-9a-fA-F:]+\])(?::[0-9]{1,5})?$/.test(req.headers.host),400,'无效的请求主机');
    if(req.headers['x-forwarded-proto'])check(req.headers['x-forwarded-proto']==='https',426,'请使用 HTTPS');
    if(req.headers.authorization?.length>256)fail(401,'登录已失效');
    const origin=req.headers.origin;
    if(origin){
      const localOrigin=origin===`http://${req.headers.host}`&&!req.headers['x-forwarded-proto'];
      const secureOrigin=origin===`https://${req.headers.host}`&&req.headers['x-forwarded-proto']==='https';
      check(origins.has(origin)||localOrigin||secureOrigin,403,'此网站来源未获允许');
    }
  }
  function response(res,status,value){if(res.writableEnded)return;res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(value));}
  function authenticateToken(token){
    check(typeof token==='string'&&/^[A-Za-z0-9_-]{43}$/.test(token),401,'请先解锁账号');
    const row=sql('SELECT * FROM sessions WHERE tokenHash=?').get(hash(token));
    check(row&&row.expiresAt>Date.now(),401,'登录已失效，请重新解锁');
    if(row.lastSeen<Date.now()-30_000)sql('UPDATE sessions SET lastSeen=? WHERE id=?').run(Date.now(),row.id);
    return row;
  }
  const auth=req=>authenticateToken(req.headers.authorization?.match(/^Bearer ([A-Za-z0-9_-]+)$/)?.[1]);
  function emit(ids,event){const serialized=JSON.stringify(event);for(const id of new Set(ids)){for(const ws of sockets.get(id)||[]){if(ws.readyState!==WebSocket.OPEN)continue;if(ws.bufferedAmount>1024*1024)ws.close(1013,'Reconnect');else ws.send(serialized);}}}
  function revoke(sessionId){sql('DELETE FROM sessions WHERE id=?').run(sessionId);for(const set of sockets.values())for(const ws of set)if(ws.sessionId===sessionId)ws.close(4001,'Session revoked');}
  function makeChallenge(id){
    check(challenges.size<5000,503,'服务器繁忙');
    const challengeId=randomUUID(),expiresAt=Date.now()+challengeMs;
    const text=`LYRA-03 login\nAccount: ${id}\nChallenge: ${challengeId}\nNonce: ${randomBytes(32).toString('base64url')}\nExpires: ${expiresAt}`;
    challenges.set(challengeId,{id,challenge:text,expiresAt});return {challengeId,challenge:text};
  }
  async function guardedCrypto(fn){check(cryptoBusy<4,503,'加密验证繁忙，请重试');cryptoBusy++;try{return await fn();}finally{cryptoBusy--;}}
  async function validateKeys(publicKey,encryptedPrivateKey){
    check(safeString(publicKey,32768)&&safeString(encryptedPrivateKey,65536),400,'密钥格式或大小无效');
    return guardedCrypto(async()=>{
      try{
        const pub=await pgp.readKey({armoredKey:publicKey}),priv=await pgp.readPrivateKey({armoredKey:encryptedPrivateKey});
        check(!pub.isPrivate()&&priv.isPrivate()&&pub.keyPacket.version===6,400,'需要有效的 v6 公钥与已加密私钥');
        check(!priv.isDecrypted()&&priv.getKeys().every(k=>!k.keyPacket.isDecrypted()),400,'拒绝保存未加密私钥');
        check(pub.getFingerprint()===priv.getFingerprint()&&Buffer.from(pub.write()).equals(Buffer.from(priv.toPublic().write())),400,'公钥和私钥不匹配');
        await pub.verifyPrimaryKey();await pub.getEncryptionKey();await pub.getSigningKey();
        return pub.getFingerprint();
      }catch(e){if(e instanceof HttpError)throw e;fail(400,'密钥无效或未正确加密');}
    });
  }
  function fileFor(user,id,write=false,requireFriend=true){
    uuid(id);const row=sql('SELECT * FROM files WHERE id=?').get(id);
    check(row&&(write?row.owner===user:row.owner===user||row.recipient===user),404,'文件不存在或无权访问');
    if(requireFriend)check(accepted(row.owner,row.recipient),403,'双方已不是好友');return row;
  }
  const chunkPath=(id,index)=>path.join(filesRoot,id,`${index}.bin`);
  async function route(req,res){
    transport(req);
    const origin=req.headers.origin;if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');}
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Cross-Origin-Resource-Policy','same-origin');res.setHeader('X-Frame-Options','DENY');
    if(req.headers['x-forwarded-proto']==='https')res.setHeader('Strict-Transport-Security','max-age=31536000');
    const socketOrigin=`${req.headers['x-forwarded-proto']==='https'?'wss':'ws'}://${req.headers.host}`;
    res.setHeader('Content-Security-Policy',`default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; connect-src 'self' ${socketOrigin}; worker-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'`);
    const url=new URL(req.url,'http://local'),pathname=url.pathname,method=req.method;
    const requestLimit=method==='PUT'&&/^\/api\/files\/[\w-]+\/chunks\/\d+$/.test(pathname)?POLICY.chunkBytes:JSON_LIMIT;
    if(req.headers['content-length']!==undefined)check(/^\d+$/.test(req.headers['content-length'])&&Number(req.headers['content-length'])<=requestLimit,413,'请求过大');
    check(!url.searchParams.has('token')&&!url.searchParams.has('access_token'),400,'登录凭证不得出现在 URL');
    if(method==='OPTIONS'){res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS');res.setHeader('Access-Control-Allow-Headers','Authorization,Content-Type');res.setHeader('Access-Control-Max-Age','300');res.writeHead(204);res.end();return;}
    const ip=peerIP(req);rate(`all:${ip}`,1800,60_000);
    if(method==='GET'&&pathname==='/health')return response(res,200,{service:'LYRA-03',version:'1.0.0',ok:true});
    if(method==='GET'&&pathname==='/api/policy')return response(res,200,POLICY);
    if(method==='POST'&&pathname==='/api/register'){
      rate(`register:${ip}`,10,3600_000);const input=await body(req);
      check(input.termsVersion===POLICY.termsVersion&&input.privacyVersion===POLICY.privacyVersion,400,'请阅读并分别同意当前条款和隐私政策');
      const fingerprint=await validateKeys(input.publicKey,input.encryptedPrivateKey);
      const existing=sql('SELECT * FROM accounts WHERE fingerprint=?').get(fingerprint);
      // A lost response must be safe to retry with the same protected identity.
      // Never replace an existing account's keys or grant a session here.
      if(existing){
        check(existing.publicKey===input.publicKey&&existing.encryptedPrivateKey===input.encryptedPrivateKey,409,'此密钥已注册，请使用原账号登录');
        return response(res,200,{id:existing.id,...makeChallenge(existing.id)});
      }
      check(sql('SELECT COUNT(*) AS n FROM accounts').get().n<10000,503,'注册名额已满');
      let id;do{id=String(randomInt(1,10));for(let i=1;i<20;i++)id+=String(randomInt(10));}while(account(id));
      const now=Date.now();sql('INSERT INTO accounts VALUES (?,?,?,?,?,?,?,?)').run(id,input.publicKey,fingerprint,input.encryptedPrivateKey,now,input.termsVersion,input.privacyVersion,now);
      audit('account-created');return response(res,201,{id,...makeChallenge(id)});
    }
    if(method==='POST'&&pathname==='/api/challenge'){
      rate(`challenge:${ip}`,60,60_000);const input=await body(req);const id=accountId(input.id),row=account(id);
      check(row,404,'账号不存在');return response(res,200,{...makeChallenge(id),publicKey:row.publicKey,encryptedPrivateKey:row.encryptedPrivateKey});
    }
    if(method==='POST'&&pathname==='/api/login'){
      rate(`login:${ip}`,40,60_000);const input=await body(req),id=accountId(input.id),challengeId=uuid(input.challengeId),entry=challenges.get(challengeId);
      challenges.delete(challengeId);
      check(entry&&entry.id===id&&entry.expiresAt>Date.now(),401,'验证已失效，请重新解锁');
      check(safeString(input.signature,16384),400,'签名无效');
      const row=account(id);
      const valid=await guardedCrypto(async()=>{try{const result=await pgp.verify({message:await pgp.createMessage({text:entry.challenge}),signature:await pgp.readSignature({armoredSignature:input.signature}),verificationKeys:await pgp.readKey({armoredKey:row.publicKey}),expectSigned:true});check(result.signatures.length===1,401,'签名无效');await result.signatures[0].verified;return true;}catch{return false;}});
      check(valid,401,'无法验证账号签名');
      const now=Date.now(),token=randomBytes(32).toString('base64url'),sessionId=randomUUID(),expiresAt=now+sessionMs;
      const prior=sql('SELECT id FROM sessions WHERE account=? ORDER BY createdAt DESC').all(id);for(const s of prior.slice(19))revoke(s.id);
      sql('INSERT INTO sessions VALUES (?,?,?,?,?,?,?)').run(sessionId,id,hash(token),cleanDevice(input.deviceName),now,now,expiresAt);
      emit([id],{type:'sessions'});return response(res,200,{token,id,expiresAt});
    }
    const publicLookup=pathname.match(/^\/api\/accounts\/(\d+)$/);
    if(method==='GET'&&publicLookup){rate(`lookup:${ip}`,60,60_000);const row=account(accountId(publicLookup[1]));check(row,404,'找不到这个好友号');return response(res,200,profile(row));}
    if(!pathname.startsWith('/api/')){
      check(method==='GET'||method==='HEAD',405,'不支持此方法');
      let decoded;try{decoded=decodeURIComponent(pathname);}catch{fail(400,'路径无效');}
      check(!decoded.includes('\\')&&!decoded.includes('\0'),400,'路径无效');
      const file=path.resolve(staticDir,'.'+(decoded==='/'?'/index.html':decoded));
      check(file.startsWith(path.resolve(staticDir)+path.sep),404,'未找到');
      const ext=path.extname(file).toLowerCase(),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json','.txt':'text/plain; charset=utf-8','.wasm':'application/wasm'};
      check(types[ext],404,'未找到');let size;try{size=(await stat(file)).size;}catch{fail(404,'未找到');}
      res.writeHead(200,{'Content-Type':types[ext],'Content-Length':size});if(method==='HEAD')return res.end();createReadStream(file).on('error',()=>res.destroy()).pipe(res);return;
    }
    const session=auth(req),user=session.account;rate(`user:${user}`,1200,60_000);
    if(method==='POST'&&pathname==='/api/logout'){revoke(session.id);return response(res,200,{ok:true});}
    if(method==='GET'&&pathname==='/api/me')return response(res,200,profile(account(user)));
    if(method==='GET'&&pathname==='/api/sessions')return response(res,200,{sessions:sql('SELECT id,deviceName,createdAt,lastSeen,expiresAt FROM sessions WHERE account=? AND expiresAt>? ORDER BY createdAt DESC').all(user,Date.now()).map(s=>({...s,current:s.id===session.id}))});
    const revokePath=pathname.match(/^\/api\/sessions\/([\w-]+)$/);
    if(method==='DELETE'&&revokePath){const id=uuid(revokePath[1]);check(sql('SELECT id FROM sessions WHERE id=? AND account=?').get(id,user),404,'会话不存在');revoke(id);emit([user],{type:'sessions'});return response(res,200,{ok:true});}
    if(method==='GET'&&pathname==='/api/friends'){
      const result={friends:[],incoming:[],outgoing:[]};for(const rel of sql('SELECT * FROM friends WHERE a=? OR b=?').all(user,user)){const other=rel.a===user?rel.b:rel.a;result[rel.status==='accepted'?'friends':rel.requestedBy===user?'outgoing':'incoming'].push(profile(account(other)));}return response(res,200,result);
    }
    if(method==='POST'&&pathname==='/api/friends/request'){
      rate(`friend:${user}`,40,3600_000);const input=await body(req),other=accountId(input.id);check(other!==user,400,'不能添加自己');check(account(other),404,'找不到这个好友号');
      check(sql('SELECT COUNT(*) n FROM friends WHERE a=? OR b=?').get(user,user).n<1000,409,'好友及申请数量已达上限');
      const rel=relationship(user,other);if(!rel)sql('INSERT INTO friends VALUES (?,?,?,?,?)').run(...pair(user,other),user,'pending',Date.now());
      emit([user,other],{type:'friends'});return response(res,200,{ok:true});
    }
    const friendAccept=pathname.match(/^\/api\/friends\/(\d+)\/accept$/);
    if(method==='POST'&&friendAccept){const other=accountId(friendAccept[1]),rel=relationship(user,other);check(rel&&rel.requestedBy===other,404,'好友申请不存在');sql("UPDATE friends SET status='accepted' WHERE a=? AND b=?").run(...pair(user,other));emit([user,other],{type:'friends'});return response(res,200,{ok:true});}
    const friendDelete=pathname.match(/^\/api\/friends\/(\d+)$/);
    if(method==='DELETE'&&friendDelete){const other=accountId(friendDelete[1]);sql('DELETE FROM friends WHERE a=? AND b=?').run(...pair(user,other));emit([user,other],{type:'friends'});return response(res,200,{ok:true});}
    if(method==='POST'&&pathname==='/api/messages'){
      rate(`send:${user}`,180,60_000);const input=await body(req),other=accountId(input.to),clientId=uuid(input.clientId);
      check(accepted(user,other),403,'请先互相添加好友');
      check(safeString(input.ciphertext,CIPHER_LIMIT)&&input.ciphertext.startsWith('-----BEGIN PGP MESSAGE-----')&&input.ciphertext.includes('-----END PGP MESSAGE-----'),400,'需要加密消息');
      try{const parsed=await pgp.readMessage({armoredMessage:input.ciphertext});check(parsed.getEncryptionKeyIDs().length>0&&parsed.packets.some(packet=>[pgp.enums.packet.symEncryptedIntegrityProtectedData,pgp.enums.packet.aeadEncryptedData].includes(packet.constructor.tag)),400,'需要完整性保护的加密消息');}catch(error){if(error instanceof HttpError)throw error;fail(400,'加密消息格式无效');}
      let row=sql('SELECT * FROM messages WHERE sender=? AND clientId=?').get(user,clientId);
      if(row){check(row.recipient===other&&row.ciphertext===input.ciphertext,409,'请求标识已被另一条消息使用');return response(res,200,{message:message(row)});}
      check(sql('SELECT COUNT(*) n FROM messages WHERE sender=?').get(user).n<100000,507,'消息存储额度已满');
      const bytes=Buffer.byteLength(input.ciphertext);check(sql("SELECT bytes FROM storage_counters WHERE name='messages'").get().bytes+sql('SELECT COALESCE(SUM(cipherBytes),0) n FROM files').get().n+bytes<=maxStorageBytes,507,'服务器密文存储空间不足');
      db.exec('BEGIN IMMEDIATE');let inserted;try{inserted=sql('INSERT INTO messages(sender,recipient,clientId,ciphertext,createdAt) VALUES (?,?,?,?,?)').run(user,other,clientId,input.ciphertext,Date.now());sql("UPDATE storage_counters SET bytes=bytes+? WHERE name='messages'").run(bytes);db.exec('COMMIT');}catch(error){db.exec('ROLLBACK');throw error;}row=sql('SELECT * FROM messages WHERE id=?').get(inserted.lastInsertRowid);
      emit([user,other],{type:'message',message:message(row)});return response(res,201,{message:message(row)});
    }
    if(method==='GET'&&pathname==='/api/messages'){
      const other=accountId(url.searchParams.get('peer'));check(accepted(user,other),403,'无权读取此会话');
      const after=integer(Number(url.searchParams.get('after')||0),0,Number.MAX_SAFE_INTEGER),limit=integer(Number(url.searchParams.get('limit')||100),1,100);
      const rows=sql('SELECT * FROM messages WHERE ((sender=? AND recipient=?) OR (sender=? AND recipient=?)) AND id>? ORDER BY id LIMIT ?').all(user,other,other,user,after,limit+1);
      return response(res,200,{messages:rows.slice(0,limit).map(message),hasMore:rows.length>limit});
    }
    if(method==='POST'&&pathname==='/api/files'){
      rate(`file:${user}`,60,3600_000);const input=await body(req),other=accountId(input.to),clientId=uuid(input.clientId),cipherBytes=integer(input.cipherBytes,1,MAX_CIPHER_BYTES),totalChunks=integer(input.totalChunks,1,1400);
      check(totalChunks===Math.ceil(cipherBytes/POLICY.chunkBytes),400,'分块数量与大小不一致');check(accepted(user,other),403,'请先互相添加好友');
      const existing=sql('SELECT * FROM files WHERE owner=? AND clientId=?').get(user,clientId);
      if(existing){check(existing.recipient===other&&existing.cipherBytes===cipherBytes&&existing.totalChunks===totalChunks,409,'上传标识已被使用');return response(res,200,{id:existing.id,chunkBytes:POLICY.chunkBytes});}
      check(sql('SELECT COALESCE(SUM(cipherBytes),0) n FROM files').get().n+sql("SELECT bytes FROM storage_counters WHERE name='messages'").get().bytes+cipherBytes<=maxStorageBytes,507,'服务器密文存储空间不足');
      check(sql('SELECT COALESCE(SUM(cipherBytes),0) n FROM files WHERE owner=?').get(user).n+cipherBytes<=maxAccountStorageBytes,507,'此账号文件额度已满');
      check(sql('SELECT COUNT(*) n FROM files WHERE owner=? AND complete=0').get(user).n<10,409,'未完成上传过多，请先继续或取消');
      const id=randomUUID();sql('INSERT INTO files(id,owner,recipient,clientId,totalChunks,cipherBytes,createdAt) VALUES (?,?,?,?,?,?,?)').run(id,user,other,clientId,totalChunks,cipherBytes,Date.now());
      try{await mkdir(path.join(filesRoot,id),{mode:0o700});}catch(error){sql('DELETE FROM files WHERE id=?').run(id);throw error;}
      return response(res,201,{id,chunkBytes:POLICY.chunkBytes});
    }
    const fileRoute=pathname.match(/^\/api\/files\/([\w-]+)(?:\/(status|complete|chunks)(?:\/(\d+))?)?$/);
    if(fileRoute){
      const [,id,action,indexString]=fileRoute,row=fileFor(user,id,method==='PUT'||method==='DELETE'||method==='POST',method!=='DELETE');
      if(method==='GET'&&action==='status')return response(res,200,{id,received:sql('SELECT idx FROM chunks WHERE fileId=? ORDER BY idx').all(id).map(c=>c.idx),complete:!!row.complete,totalChunks:row.totalChunks,cipherBytes:row.cipherBytes});
      if(method==='PUT'&&action==='chunks'&&indexString!==undefined){
        const index=integer(Number(indexString),0,row.totalChunks-1),key=`${id}/${index}`;
        check(uploadLocks.size<16,503,'上传通道繁忙，请重试');check(!uploadLocks.has(key)&&!uploadLocks.has(id),409,'此分块正在写入，请重试');uploadLocks.add(key);
        try{
          const expected=index===row.totalChunks-1?row.cipherBytes-index*POLICY.chunkBytes:POLICY.chunkBytes;
          const bytes=await body(req,POLICY.chunkBytes,true);check(bytes.length===expected,400,'分块大小不匹配');const digest=hash(bytes),old=sql('SELECT * FROM chunks WHERE fileId=? AND idx=?').get(id,index);
          if(old){check(old.digest===digest&&old.bytes===bytes.length,409,'禁止替换已接收的分块');return response(res,200,{ok:true,index});}
          check(!row.complete,409,'文件已完成');
          const temporary=chunkPath(id,index)+'.tmp';await writeFile(temporary,bytes,{flag:'w',mode:0o600});await rename(temporary,chunkPath(id,index));sql('INSERT INTO chunks VALUES (?,?,?,?)').run(id,index,bytes.length,digest);
          return response(res,200,{ok:true,index});
        }finally{uploadLocks.delete(key);}
      }
      if(method==='POST'&&action==='complete'){
        const total=sql('SELECT COUNT(*) n,COALESCE(SUM(bytes),0) bytes FROM chunks WHERE fileId=?').get(id);check(total.n===row.totalChunks&&total.bytes===row.cipherBytes,409,'文件尚未上传完整');sql('UPDATE files SET complete=1 WHERE id=?').run(id);return response(res,200,{id,complete:true});
      }
      if(method==='GET'&&action==='chunks'&&indexString!==undefined){
        check(row.complete,409,'文件尚未上传完整');const index=integer(Number(indexString),0,row.totalChunks-1),chunk=sql('SELECT * FROM chunks WHERE fileId=? AND idx=?').get(id,index);check(chunk,404,'分块不存在');
        res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':chunk.bytes,'Content-Disposition':'attachment; filename="encrypted-chunk.bin"'});createReadStream(chunkPath(id,index)).on('error',()=>res.destroy()).pipe(res);return;
      }
      if(method==='DELETE'&&!action){
        check(![...uploadLocks].some(k=>k===id||k.startsWith(id+'/')),409,'上传正在写入，请稍后取消');uploadLocks.add(id);
        try{const children=await readdir(path.join(filesRoot,id));for(const child of children){check(/^\d+\.bin(?:\.tmp)?$/.test(child),500,'存储目录异常');await unlink(path.join(filesRoot,id,child));}sql('DELETE FROM files WHERE id=?').run(id);return response(res,200,{ok:true});}finally{uploadLocks.delete(id);}
      }
    }
    fail(404,'接口不存在');
  }
  const server=http.createServer((req,res)=>{route(req,res).catch(error=>{if(res.headersSent)return res.destroy();response(res,error.status||500,{error:error instanceof HttpError?error.message:'服务器暂时无法处理请求'});});});
  server.requestTimeout=120000;server.headersTimeout=15000;server.keepAliveTimeout=5000;server.maxRequestsPerSocket=1000;
  server.on('clientError',(_error,socket)=>{if(socket.writable)socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');});
  const wss=new WebSocketServer({noServer:true,maxPayload:8192,perMessageDeflate:false});
  server.on('upgrade',(req,socket,head)=>{
    try{transport(req);const url=new URL(req.url,'http://local');check(url.pathname==='/ws'&&!url.search,400,'Invalid websocket path');rate(`ws:${peerIP(req)}`,60,60_000);wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));}
    catch{socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');}
  });
  wss.on('connection',ws=>{
    ws.alive=true;let user=null;
    const authTimer=setTimeout(()=>{if(!user)ws.close(4001,'Authentication required');},5000);authTimer.unref();
    ws.on('pong',()=>ws.alive=true);
    ws.on('message',(raw,isBinary)=>{try{check(!isBinary,400,'Text only');const input=JSON.parse(raw.toString());check(!user&&input.type==='auth',400,'Authentication only');const session=authenticateToken(input.token);user=session.account;ws.sessionId=session.id;ws.expiresAt=session.expiresAt;clearTimeout(authTimer);if(!sockets.has(user))sockets.set(user,new Set());sockets.get(user).add(ws);ws.send(JSON.stringify({type:'ready'}));}catch{ws.close(4001,'Authentication failed');}});
    ws.on('close',()=>{clearTimeout(authTimer);if(user){sockets.get(user)?.delete(ws);if(!sockets.get(user)?.size)sockets.delete(user);}});ws.on('error',()=>{});
  });
  const housekeeping=setInterval(()=>{
    const now=Date.now();for(const [id,c]of challenges)if(c.expiresAt<now)challenges.delete(id);for(const [key,b]of buckets)if(b.until<now)buckets.delete(key);
    sql('DELETE FROM sessions WHERE expiresAt<=?').run(now);
    for(const ws of wss.clients){if(!ws.alive||ws.expiresAt<=now){ws.terminate();continue;}ws.alive=false;ws.ping();}
  },30000);housekeeping.unref();
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);}).catch(error=>{clearInterval(housekeeping);db.close();throw error;});
  const address=server.address(),baseUrl=`http://${host.includes(':')?'['+host+']':host}:${address.port}`;
  return {server,db,port:address.port,baseUrl,dataDir:root,async close(){if(closing)return;closing=true;clearInterval(housekeeping);for(const ws of wss.clients)ws.terminate();await new Promise(resolve=>wss.close(resolve));await new Promise(resolve=>{server.close(resolve);server.closeAllConnections();});db.close();},stats(){return {accounts:sql('SELECT COUNT(*) n FROM accounts').get().n,messages:sql('SELECT COUNT(*) n FROM messages').get().n,files:sql('SELECT COUNT(*) n FROM files').get().n,cipherBytes:sql('SELECT COALESCE(SUM(cipherBytes),0) n FROM files').get().n,connections:wss.clients.size};}};
}
