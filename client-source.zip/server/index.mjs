import { createRelay } from './relay.mjs';
import { homedir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const relay=await createRelay({dataDir:process.env.LYRA_DATA_DIR||path.join(homedir(),'Lyra03Data','v1'),port:Number(process.env.LYRA_PORT||8596),host:process.env.LYRA_HOST||'127.0.0.1',staticDir:process.env.LYRA_STATIC_DIR||path.join(project,'dist'),allowedOrigins:(process.env.LYRA_ALLOWED_ORIGINS||'https://gonggong1234dyendui-crypto.github.io').split(',').filter(Boolean)});
console.log(JSON.stringify({service:'LYRA-03',version:'1.0.0',event:'listening',port:relay.port}));
let stopping=false;async function stop(){if(stopping)return;stopping=true;await relay.close();process.exit(0);}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
